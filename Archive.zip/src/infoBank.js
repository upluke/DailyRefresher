


export const infoBank=[
    {
        id:"ai_eighteen_1",
        info:"frequency is the reciprocal of period."
    },
    {
        id:"ai_eighteen_2",
        info:"Today we're gonna watch the preliminary of one poppers."
    },
    {
        id:"ai_eighteen_3",
        info:"You're still stuffing your face while I'm talking to you."
    },
    {
        id:"ai_eighteen_4",
        info:"I thought she was of age."
    },
    {
        id:"ai_eighteen_5",
        info:"Direction, it carries the idea of something traveling in a certain direction like east weast north or south."
    },
    {
        id:"ai_eighteen_6",
        info:"To be honest, I still felt it's surreal."
    },
    {
        id:"ai_eighteen_7",
        info:"A handful of soil was strewn onto his coffin."
    },
    {
        id:"ai_eighteen_8",
        info:"He suffers from health problems, including hallucinations, tuberculosis and epilepsy."
    },
    {
        id:"ai_eighteen_9",
        info:"I think a big part of why schubert never achieved fame, I don't mean it in a harsh way but I think part of that was his personality."
    },
    {
        id:"ai_eighteen_10",
        info:"He wasn't a very outgoing personality type. Actually he was quite the opposite. He's very shy and sort of anti-social so that didn't help him very much in the romance department."
    },
    {
        id:"ai_eighteen_11",
        info:"Obviously everything he touched turned to gold."
    },
    {
        id:"ai_eighteen_12",
        info:"He was on the cusp of a new generation of musci, but being a transitional composer maybe some of his music didn't exactly resonate with the peiple of his time."
    },
    {
        id:"ai_eighteen_13",
        info:"Schubert died of typhoid fever. He didn't have either money or the inclination to travel."
    },
    {
        id:"ai_eighteen_14",
        info:"Violins are in a higher register than cellos."
    },
    {
        id:"ai_eighteen_15",
        info:"She will take him under her wing."
    }
];

export default infoBank


// export const infoBank=[
   
//     "frequency is the reciprocal of period.",
//     "Today we're gonna watch the preliminary of one poppers.",
//   "You're still stuffing your face while I'm talking to you.",
//  "I thought she was of age.",
//    "Direction, it carries the idea of something traveling in a certain direction like east weast north or south.",

//     "To be honest, I still felt it's surreal.",

//     "A handful of soil was strewn onto his coffin."
// ,

//     "He suffers from health problems, including hallucinations, tuberculosis and epilepsy."
// ,

//     "I think a big part of why schubert never achieved fame, I don't mean it in a harsh way but I think part of that was his personality."
// ,

  
//     "He wasn't a very outgoing personality type. Actually he was quite the opposite. He's very shy and sort of anti-social so that didn't help him very much in the romance department."
// ,

//     "Obviously everything he touched turned to gold."
// ,

   
//     "He was on the cusp of a new generation of musci, but being a transitional composer maybe some of his music didn't exactly resonate with the peiple of his time."
// ,

//     "Schubert died of typhoid fever. He didn't have either money or the inclination to travel."
// ,

//     "Violins are in a higher register than cellos."
// ,

//     "She will take him under her wing."

// ];

// export default infoBank
