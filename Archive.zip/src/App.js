import React from 'react';
import Colloquialboard from './Components/Colloquialboard/Colloquialboard'

import './App.css';

function App() {
  return (
    <div className="App">
      <Colloquialboard />
    </div>
  );
}

export default App;
